#ifndef _ioconfig_h
#define _ioconfig_h


void ButtonConf(void);
void EXTI0_IRQHandler(void); //interrupt handler


#endif