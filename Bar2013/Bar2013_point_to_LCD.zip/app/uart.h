#ifndef _uart_h
#define _uart_h
#include "stm32F10x.h"

char write_UART1(unsigned char * SMS);
char Init_UART1(void);

#endif