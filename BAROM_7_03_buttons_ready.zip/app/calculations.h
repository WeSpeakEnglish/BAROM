#ifndef _calculations_h
#define _calculations_h
#include "stm32F10x.h"

u32 getMiddle(u32 Value);
#endif